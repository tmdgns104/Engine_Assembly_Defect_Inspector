"""Image quality package."""
