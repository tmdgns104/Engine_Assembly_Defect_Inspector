"""Recipe package."""
