"""Camera package."""
